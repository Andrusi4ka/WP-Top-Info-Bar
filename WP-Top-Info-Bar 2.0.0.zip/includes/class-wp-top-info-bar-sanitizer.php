<?php

if (! defined('ABSPATH')) {
	exit;
}

final class WP_Top_Info_Bar_Sanitizer {
	public function sanitize_settings(array $input): array {
		return array(
			'enabled'          => empty($input['enabled']) ? 0 : 1,
			'message'          => isset($input['message']) ? sanitize_textarea_field($input['message']) : '',
			'background_color' => $this->sanitize_hex_color($input['background_color'] ?? '#1f2937'),
			'text_color'       => $this->sanitize_hex_color($input['text_color'] ?? '#ffffff', '#ffffff'),
			'animation'        => $this->sanitize_animation($input['animation'] ?? 'none'),
			'text_delay'       => $this->sanitize_animation_delay($input['text_delay'] ?? ''),
			'font_size'        => $this->sanitize_css_size($input['font_size'] ?? '14px', '14px'),
			'font_size_tablet' => $this->sanitize_css_size($input['font_size_tablet'] ?? '', ''),
			'font_size_mobile' => $this->sanitize_css_size($input['font_size_mobile'] ?? '', ''),
			'padding'          => $this->sanitize_spacing_value($input['padding'] ?? '12px 16px'),
			'padding_tablet'   => $this->sanitize_spacing_value($input['padding_tablet'] ?? ''),
			'padding_mobile'   => $this->sanitize_spacing_value($input['padding_mobile'] ?? ''),
			'margin'           => $this->sanitize_spacing_value($input['margin'] ?? ''),
			'margin_tablet'    => $this->sanitize_spacing_value($input['margin_tablet'] ?? ''),
			'margin_mobile'    => $this->sanitize_spacing_value($input['margin_mobile'] ?? ''),
			'custom_class'     => $this->sanitize_class_list($input['custom_class'] ?? ''),
			'custom_id'        => $this->sanitize_html_identifier($input['custom_id'] ?? ''),
			'images'           => $this->sanitize_images($input['images'] ?? array()),
		);
	}

	public function sanitize_hex_color(string $color, string $fallback = '#1f2937'): string {
		$sanitized = sanitize_hex_color($color);

		return $sanitized ? $sanitized : $fallback;
	}

	public function sanitize_spacing_value(string $value): string {
		$value = sanitize_text_field($value);

		return preg_replace('/[^0-9a-zA-Z.%\-\s(),\/]/', '', $value) ?? '';
	}

	public function sanitize_css_size(string $value, string $fallback): string {
		$value = sanitize_text_field($value);
		$sanitized = preg_replace('/[^0-9a-zA-Z.%\-\s(),\/]/', '', $value) ?? '';

		return '' !== trim($sanitized) ? $sanitized : $fallback;
	}

	public function sanitize_class_list(string $classes): string {
		$classes = preg_split('/\s+/', sanitize_text_field($classes)) ?: array();
		$classes = array_filter(array_map('sanitize_html_class', $classes));

		return implode(' ', $classes);
	}

	public function sanitize_html_identifier(string $value): string {
		return sanitize_html_class(sanitize_text_field($value));
	}

	public function sanitize_animation(string $value): string {
		$allowed = array('none', 'fade-in', 'slide-up', 'from-left', 'from-right', 'page-left', 'page-right', 'blink', 'scale-pulse');
		$value = sanitize_key($value);

		return in_array($value, $allowed, true) ? $value : 'none';
	}

	public function sanitize_image_animation(string $value): string {
		$allowed = array('none', 'rotate-swing-top', 'rotate-swing-bottom', 'slide-sideways', 'blink', 'scale-pulse');
		$value = sanitize_key($value);

		return in_array($value, $allowed, true) ? $value : 'none';
	}

	public function sanitize_animation_delay(string $value): string {
		$value = strtolower(trim(sanitize_text_field($value)));

		if ('' === $value) {
			return '';
		}

		if (preg_match('/^\d+(?:\.\d+)?$/', $value)) {
			return $value . 'ms';
		}

		if (preg_match('/^\d+(?:\.\d+)?(?:ms|s)$/', $value)) {
			return $value;
		}

		return '';
	}

	public function sanitize_images($images): array {
		if (! is_array($images)) {
			return array();
		}

		$sanitized_images = array();

		foreach ($images as $image) {
			if (! is_array($image)) {
				continue;
			}

			$image_id = isset($image['image_id']) ? absint($image['image_id']) : 0;

			if ($image_id <= 0) {
				continue;
			}

			$sanitized_images[] = array(
				'image_id'     => $image_id,
				'size'         => $this->sanitize_css_size($image['size'] ?? '', ''),
				'size_tablet'  => $this->sanitize_css_size($image['size_tablet'] ?? '', ''),
				'size_mobile'  => $this->sanitize_css_size($image['size_mobile'] ?? '', ''),
				'margin'       => $this->sanitize_spacing_value($image['margin'] ?? ''),
				'margin_tablet'=> $this->sanitize_spacing_value($image['margin_tablet'] ?? ''),
				'margin_mobile'=> $this->sanitize_spacing_value($image['margin_mobile'] ?? ''),
				'animation'    => $this->sanitize_image_animation($image['animation'] ?? 'none'),
				'delay'        => $this->sanitize_animation_delay($image['delay'] ?? ''),
				'custom_class' => $this->sanitize_class_list($image['custom_class'] ?? ''),
				'position'     => $this->sanitize_position($image['position'] ?? 'left'),
			);
		}

		return $sanitized_images;
	}

	private function sanitize_position(string $value): string {
		$value = sanitize_key($value);

		return in_array($value, array('left', 'right', 'center-top', 'center-bottom'), true) ? $value : 'left';
	}
}
