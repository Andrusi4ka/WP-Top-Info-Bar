(function ($) {
	'use strict';

	const config = window.wpTopInfoBarAdmin || {};
	const optionName = config.optionName || 'wp_top_info_bar_settings';
	const labels = config.labels || {};

	function getNextIndex($list) {
		let maxIndex = -1;

		$list.find('[data-image-row]').each(function () {
			const name = $(this).find('[data-image-id]').attr('name') || '';
			const match = name.match(/\[images]\[(\d+)]/);

			if (match) {
				maxIndex = Math.max(maxIndex, parseInt(match[1], 10));
			}
		});

		return maxIndex + 1;
	}

	function bindImagePicker($row) {
		$row.find('[data-select-image]').off('click').on('click', function () {
			const $preview = $row.find('[data-image-preview]');
			const frame = wp.media({
				title: labels.chooseImage || 'Choose image',
				button: {
					text: labels.useImage || 'Use this image'
				},
				library: {
					type: 'image'
				},
				multiple: false
			});

			frame.on('select', function () {
				const attachment = frame.state().get('selection').first().toJSON();
				let previewUrl = attachment.url;

				if (attachment.sizes && attachment.sizes.thumbnail && attachment.sizes.thumbnail.url) {
					previewUrl = attachment.sizes.thumbnail.url;
				}

				$row.find('[data-image-id]').val(attachment.id);
				$preview
					.addClass('has-image')
					.attr('aria-label', labels.changeImage || 'Change image')
					.attr('title', labels.changeImage || 'Change image')
					.html(
						'<img src="' + previewUrl + '" alt="" />' +
						'<span class="wp-top-info-bar-image-row__preview-plus" aria-hidden="true">+</span>' +
						'<span class="wp-top-info-bar-image-row__preview-edit" aria-hidden="true"></span>'
					);
			});

			frame.open();
		});
	}

	function bindRemoveRow($row) {
		$row.find('[data-remove-image-row]').off('click').on('click', function () {
			$row.remove();
		});
	}

	function bindRow($row) {
		bindImagePicker($row);
		bindRemoveRow($row);
	}

	$(function () {
		const $list = $('[data-images-list]');
		const template = wp.template('wp-top-info-bar-image-row');

		$list.find('[data-image-row]').each(function () {
			bindRow($(this));
		});

		$('[data-add-image-row]').on('click', function () {
			const index = getNextIndex($list);
			const html = template({ index: index, optionName: optionName });
			const $row = $(html);

			$list.append($row);
			bindRow($row);
		});
	});
}(jQuery));
