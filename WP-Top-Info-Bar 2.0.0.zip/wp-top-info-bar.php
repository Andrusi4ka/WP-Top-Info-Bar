<?php
/**
 * Plugin Name: WP Top Info Bar
 * Plugin URI:  https://mysite.local
 * Description: Adds a configurable information bar at the very top of the site.
 * Version:     2.0.0
 * Author:      Relevant AS (Andrii Boiko)
 * Author URI: https://Relevant.no
 * Text Domain: wp-top-info-bar
 */

if (! defined('ABSPATH')) {
	exit;
}

if (! defined('WP_TOP_INFO_BAR_PATH')) {
	define('WP_TOP_INFO_BAR_PATH', plugin_dir_path(__FILE__));
}

if (! defined('WP_TOP_INFO_BAR_URL')) {
	define('WP_TOP_INFO_BAR_URL', plugin_dir_url(__FILE__));
}

require_once WP_TOP_INFO_BAR_PATH . 'includes/class-wp-top-info-bar-settings.php';
require_once WP_TOP_INFO_BAR_PATH . 'includes/class-wp-top-info-bar-sanitizer.php';
require_once WP_TOP_INFO_BAR_PATH . 'includes/class-wp-top-info-bar-admin.php';
require_once WP_TOP_INFO_BAR_PATH . 'includes/class-wp-top-info-bar-frontend.php';
require_once WP_TOP_INFO_BAR_PATH . 'includes/class-wp-top-info-bar.php';

register_activation_hook(__FILE__, array('WP_Top_Info_Bar', 'activate'));

WP_Top_Info_Bar::instance();
